The Bravery Typeface (Lite Version) - Free for personal and commercial use.
by Pollux of Geminorum Type Foundry
-----------------------------------

Thankyou for downloading this font!
Enjoy the font and happy make designing.

You can visit here for FULL version :
https://creativemarket.com/polluxofgeminorum/688237-The-Bravery-Bonus

If you need any help, dont hesitate to contact me to suke@toejoeh.com

Regards,
Suke



Feel Free to follow us!
-----------------------
Creative Market 
https://creativemarket.com/polluxofgeminorum

Facebook
facebook.com/polluxofgeminorum

Instagram
@polluxofgeminorum

Behance
https://www.behance.net/suketoejoeh



Here are some FAQ about font installation :
-------------------------------------------
1.How to install a font under Windows?

- Under Windows 10/8/7/Vista
  Select the font files (.ttf, .otf or .fon) then Right-click > Install

-Under any version of Windows
 Place the font files (.ttf, .otf or .fon) into the Fonts folder, usually C:\Windows\Fonts or C:\WINNT\Fonts
 (can be reached as well by the Start Menu > Control Panel > Appearance and Themes > Fonts).

Note that with the internal unzip tool of Windows (unlike Winzip), you cannot install a font by a simple drag and drop of the .ttf from the zip window to the Fonts window. You must first drag and drop it anywhere (for example on the desktop) then into the Fonts folder.
You can also go through: File > Install a new font... in the Fonts folder menu then browse the fonts, instead of drag and drop the fonts into the window. Although this method is laborious, it would seem that it functions better in some cases.


2.How to install a font under Mac OS?

- Under Mac OS X 10.3 or above (including the FontBook)
  Double-click the font file > "Install font" button at the bottom of the preview.
     
- Under any version of Mac OS X:
  Put the files into /Library/Fonts (for all users),
  or into /Users/Your_username/Library/Fonts (for you only).



     

